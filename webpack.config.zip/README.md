Small D&D map maker made in electron and three js

# Věci na udělání

* načítání map
* lepší tvary
* edit ukazatele
* další nástroje (fence tool atd...)
* vypnout program esc

# Pro Kryštofa

* rozdělit renderer.js do více files